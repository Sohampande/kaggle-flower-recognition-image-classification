import logging
import os 
from pathlib import Path 

# the logging string : 
logging.basicConfig(level=logging.INFO, format='[%(asctime)s]: %(message)s:')
project_name = 'cnn_classifier'

# github does not track empty folders. 
#       This helps us keep those empty folders in track.
#       to track a folder on github, it should have the __init__.py file
#       other files are being tracked individually in github.
#       we are using templates/index.html

list_of_files = [
    '.github/workflows/.gitkeep', 
    f"src/{project_name}/__init__.py",
    f"src/{project_name}/components/__init__.py",
    f"src/{project_name}/utils/__init__.py",
    f"src/{project_name}/config/__init__.py",
    f"src/{project_name}/config/configuration.py",
    f"src/{project_name}/pipeline/__init__.py",
    f"src/{project_name}/entity/__init__.py",
    f"src/{project_name}/constants/__init__.py",
    "config/config.yaml",
    "dvc.yaml",
    "params.yaml",
    "requirements.txt",
    "setup.py",
    "research/trials.ipynb",
    "templates/index.html",
    "test.py"
]

# to actually make this project structre, we run a simple for loop which
#       will make all of it for me :)

for filepath in list_of_files:
    filepath = Path(filepath)
    filedir, filename = os.path.split(filepath)

    if filedir != "":
        os.makedirs(filedir, exist_ok=True)
        logging.info(f"Creating directory : {filedir} for the file : {filename}")
    
    if (not os.path.exists(filepath)) or (os.path.getsize(filepath) == 0):
        with open(filepath, "w") as f:
            logging.info(f"Creating empty file : {filename}")
    
    else : 
        logging.info(f"{filename} already exists")

